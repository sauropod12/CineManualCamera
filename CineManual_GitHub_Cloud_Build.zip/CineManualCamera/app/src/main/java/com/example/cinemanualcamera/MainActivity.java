package com.example.cinemanualcamera;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 44;
    private FrameLayout root;
    private TextureView textureView;
    private TextView statusText, resolutionButton, codecButton, timerText, hintText;
    private Button recordButton;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CameraManager cameraManager;
    private String cameraId;
    private CameraCharacteristics characteristics;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private MediaRecorder mediaRecorder;
    private Uri pendingVideoUri;
    private boolean isRecording = false;
    private boolean openingCamera = false;
    private boolean use4K = true;
    private boolean useHevc = false;
    private Size videoSize;
    private Size previewSize;
    private Surface recorderSurface;
    private long recordingStartedAt;
    private final Runnable timerRunnable = new Runnable() {
        @Override public void run() {
            if (isRecording) {
                long elapsed = (System.currentTimeMillis() - recordingStartedAt) / 1000L;
                timerText.setText(String.format(Locale.US, "%02d:%02d", elapsed / 60, elapsed % 60));
                timerText.postDelayed(this, 500);
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        if (hasPermissions()) startCameraThread();
        else requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQUEST_PERMISSIONS);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        textureView = new TextureView(this);
        root.addView(textureView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(16), dp(12), dp(16), dp(12));
        top.setBackgroundColor(0xAA080A0D);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(top, topLp);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("CINE MANUAL", 15, Color.WHITE, true);
        titleRow.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        statusText = text("CAMERA STANDBY", 10, 0xFFB7C1CC, true);
        titleRow.addView(statusText);
        top.addView(titleRow);

        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setGravity(Gravity.CENTER_VERTICAL);
        infoRow.setPadding(0, dp(10), 0, 0);
        resolutionButton = chip("4K");
        codecButton = chip("H.264");
        timerText = text("00:00", 15, Color.WHITE, true);
        infoRow.addView(resolutionButton, new LinearLayout.LayoutParams(0, dp(36), 1));
        infoRow.addView(codecButton, new LinearLayout.LayoutParams(0, dp(36), 1));
        infoRow.addView(timerText, new LinearLayout.LayoutParams(0, dp(36), 1));
        top.addView(infoRow);

        hintText = text("AUTO EXPOSURE  •  30 FPS TARGET  •  MP4", 10, 0xFFE0E0E0, false);
        hintText.setPadding(0, dp(9), 0, 0);
        top.addView(hintText);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(18), dp(18), dp(18), dp(22));
        bottom.setBackgroundColor(0xCC080A0D);
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(bottom, bottomLp);

        TextView note = text("PRO VIDEO  /  REAR CAMERA", 10, 0xFFB7C1CC, true);
        note.setGravity(Gravity.CENTER);
        bottom.addView(note, new LinearLayout.LayoutParams(-1, dp(24)));

        recordButton = new Button(this);
        recordButton.setText("●  START RECORDING");
        recordButton.setTextColor(Color.WHITE);
        recordButton.setTextSize(14);
        recordButton.setAllCaps(false);
        recordButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB52B35));
        bottom.addView(recordButton, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView footer = text("Clips save to Movies/CineManual", 10, 0xFF9DA6B1, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(9), 0, 0);
        bottom.addView(footer);

        setContentView(root);
        resolutionButton.setOnClickListener(v -> {
            if (isRecording) return;
            use4K = !use4K;
            resolutionButton.setText(use4K ? "4K" : "1080p");
            if (textureView.isAvailable()) reopenCamera();
        });
        codecButton.setOnClickListener(v -> {
            if (isRecording) {
                toast("Stop recording before changing codec");
                return;
            }
            useHevc = !useHevc;
            codecButton.setText(useHevc ? "H.265" : "H.264");
            hintText.setText(useHevc ? "HEVC SELECTED • DEVICE SUPPORT VARIES • MP4" :
                    "AUTO EXPOSURE  •  30 FPS TARGET  •  MP4");
            if (textureView.isAvailable()) reopenCamera();
        });
        recordButton.setOnClickListener(v -> {
            if (isRecording) stopRecording();
            else startRecording();
        });
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
                if (hasPermissions()) openCamera();
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
        });
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private TextView chip(String value) {
        TextView t = text(value, 12, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(0xFF252A31);
        t.setPadding(dp(8), 0, dp(8), 0);
        return t;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean hasPermissions() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (hasPermissions()) {
                startCameraThread();
                if (textureView.isAvailable()) openCamera();
            } else {
                statusText.setText("PERMISSIONS REQUIRED");
                toast("Camera and microphone permissions are needed to record video.");
            }
        }
    }

    private void startCameraThread() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("CineCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        if (textureView.isAvailable()) openCamera();
    }

    private void openCamera() {
        if (openingCamera || cameraDevice != null || !hasPermissions()) return;
        openingCamera = true;
        try {
            cameraId = findBackCamera();
            if (cameraId == null) throw new IllegalStateException("No rear camera found");
            characteristics = cameraManager.getCameraCharacteristics(cameraId);
            chooseSizes();
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    openingCamera = false;
                    cameraDevice = camera;
                    statusText.setText("CAMERA READY");
                    createPreviewSession();
                }
                @Override public void onDisconnected(CameraDevice camera) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    statusText.setText("CAMERA DISCONNECTED");
                }
                @Override public void onError(CameraDevice camera, int error) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    statusText.setText("CAMERA ERROR " + error);
                    toast("Camera failed to open (" + error + ")");
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
            statusText.setText("CAMERA UNAVAILABLE");
            toast("Unable to open camera: " + e.getMessage());
        }
    }

    private String findBackCamera() throws CameraAccessException {
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        return null;
    }

    private void chooseSizes() throws CameraAccessException {
        StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) throw new IllegalStateException("Camera has no stream configuration map");
        Size[] sizes = map.getOutputSizes(MediaRecorder.class);
        if (sizes == null || sizes.length == 0) throw new IllegalStateException("No supported video sizes");
        List<Size> candidates = new ArrayList<>(Arrays.asList(sizes));
        Collections.sort(candidates, (a, b) -> Long.compare((long)b.getWidth()*b.getHeight(), (long)a.getWidth()*a.getHeight()));

        Size selected = null;
        if (use4K) {
            for (Size s : candidates) {
                if (s.getWidth() >= 3840 && s.getHeight() >= 2160) { selected = s; break; }
            }
        }
        if (selected == null) {
            for (Size s : candidates) {
                if (s.getWidth() == 1920 && s.getHeight() == 1080) { selected = s; break; }
            }
        }
        if (selected == null) selected = candidates.get(candidates.size() - 1);
        videoSize = selected;

        Size[] previews = map.getOutputSizes(SurfaceTexture.class);
        previewSize = videoSize;
        if (previews != null && previews.length > 0) {
            Size best = null;
            double targetRatio = (double) videoSize.getWidth() / videoSize.getHeight();
            for (Size s : previews) {
                if (s.getWidth() <= 1920 && Math.abs((double)s.getWidth()/s.getHeight() - targetRatio) < 0.03) {
                    if (best == null || s.getWidth() > best.getWidth()) best = s;
                }
            }
            if (best == null) best = previews[0];
            previewSize = best;
        }
        hintText.setText(videoSize.getWidth() + "×" + videoSize.getHeight() + "  •  AUTO EXPOSURE  •  MP4");
        resolutionButton.setText(videoSize.getWidth() >= 3840 ? "4K" : (videoSize.getWidth() >= 1920 ? "1080p" : "MAX"));
    }

    private void createPreviewSession() {
        if (cameraDevice == null || !textureView.isAvailable()) return;
        try {
            SurfaceTexture texture = textureView.getSurfaceTexture();
            texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface previewSurface = new Surface(texture);
            CaptureRequest.Builder request = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            request.addTarget(previewSurface);
            request.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            request.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
            cameraDevice.createCaptureSession(Arrays.asList(previewSurface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    if (cameraDevice == null) return;
                    captureSession = session;
                    try {
                        session.setRepeatingRequest(request.build(), null, cameraHandler);
                    } catch (CameraAccessException e) {
                        toast("Preview request failed");
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    statusText.setText("PREVIEW CONFIG FAILED");
                    toast("Camera preview configuration failed");
                }
            }, cameraHandler);
        } catch (Exception e) {
            toast("Preview error: " + e.getMessage());
        }
    }

    private void startRecording() {
        if (cameraDevice == null || isRecording) {
            if (cameraDevice == null) toast("Camera is not ready yet");
            return;
        }
        try {
            prepareMediaRecorder();
            SurfaceTexture texture = textureView.getSurfaceTexture();
            texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface previewSurface = new Surface(texture);
            recorderSurface = mediaRecorder.getSurface();

            CaptureRequest.Builder request = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            request.addTarget(previewSurface);
            request.addTarget(recorderSurface);
            request.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            request.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
            request.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            try {
                android.hardware.camera2.params.StreamConfigurationMap map =
                        characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                android.util.Range<Integer>[] ranges = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                if (ranges != null) {
                    android.util.Range<Integer> chosen = null;
                    for (android.util.Range<Integer> r : ranges) {
                        if (r.getLower() <= 30 && r.getUpper() >= 30) { chosen = r; break; }
                    }
                    if (chosen != null) request.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, chosen);
                }
            } catch (Exception ignored) {}

            cameraDevice.createCaptureSession(Arrays.asList(previewSurface, recorderSurface),
                    new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    captureSession = session;
                    try {
                        session.setRepeatingRequest(request.build(), null, cameraHandler);
                        mediaRecorder.start();
                        isRecording = true;
                        recordingStartedAt = System.currentTimeMillis();
                        recordButton.setText("■  STOP RECORDING");
                        statusText.setText("● REC");
                        statusText.setTextColor(0xFFFF5252);
                        timerText.setText("00:00");
                        timerText.post(timerRunnable);
                        resolutionButton.setAlpha(0.5f);
                        codecButton.setAlpha(0.5f);
                    } catch (Exception e) {
                        cleanupFailedRecording();
                        toast("Recording could not start: " + e.getMessage());
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    cleanupFailedRecording();
                    toast("Recording session failed. Try 1080p or H.264.");
                }
            }, cameraHandler);
        } catch (Exception e) {
            cleanupFailedRecording();
            toast("Could not prepare recorder: " + e.getMessage());
        }
    }

    private void prepareMediaRecorder() throws IOException {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setVideoEncoder(useHevc ? MediaRecorder.VideoEncoder.HEVC : MediaRecorder.VideoEncoder.H264);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
        mediaRecorder.setVideoFrameRate(30);
        mediaRecorder.setVideoEncodingBitRate(videoSize.getWidth() >= 3840 ? 50000000 : 16000000);
        mediaRecorder.setAudioEncodingBitRate(128000);
        mediaRecorder.setAudioSamplingRate(44100);
        if (Build.VERSION.SDK_INT >= 26) mediaRecorder.setOutputFile(createMediaStoreOutput());
        else throw new IOException("Android 10 or newer is required");
        mediaRecorder.setOrientationHint(90);
        mediaRecorder.prepare();
    }

    private FileDescriptor createMediaStoreOutput() throws IOException {
        ContentValues values = new ContentValues();
        String name = "CineManual_" + System.currentTimeMillis() + ".mp4";
        values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CineManual");
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Video.Media.IS_PENDING, 1);
        pendingVideoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (pendingVideoUri == null) throw new IOException("Could not create video in MediaStore");
        android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(pendingVideoUri, "w");
        if (pfd == null) throw new IOException("Could not open output video file");
        // MediaRecorder owns the file descriptor during recording; retain the PFD so it stays open.
        outputPfd = pfd;
        return pfd.getFileDescriptor();
    }

    private android.os.ParcelFileDescriptor outputPfd;

    private void stopRecording() {
        if (!isRecording) return;
        isRecording = false;
        timerText.removeCallbacks(timerRunnable);
        try {
            if (captureSession != null) {
                try { captureSession.stopRepeating(); } catch (Exception ignored) {}
                try { captureSession.abortCaptures(); } catch (Exception ignored) {}
                captureSession.close();
                captureSession = null;
            }
            mediaRecorder.stop();
            mediaRecorder.reset();
            mediaRecorder.release();
            mediaRecorder = null;
            if (outputPfd != null) {
                outputPfd.close();
                outputPfd = null;
            }
            if (pendingVideoUri != null) {
                ContentValues values = new ContentValues();
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(pendingVideoUri, values, null, null);
                pendingVideoUri = null;
            }
            toast("Video saved to Movies/CineManual");
        } catch (Exception e) {
            deletePendingVideo();
            toast("Recording stopped, but the file may be incomplete.");
        } finally {
            if (recorderSurface != null) {
                recorderSurface.release();
                recorderSurface = null;
            }
            recordButton.setText("●  START RECORDING");
            statusText.setText("CAMERA READY");
            statusText.setTextColor(0xFFB7C1CC);
            resolutionButton.setAlpha(1f);
            codecButton.setAlpha(1f);
            timerText.setText("00:00");
            createPreviewSession();
        }
    }

    private void cleanupFailedRecording() {
        isRecording = false;
        timerText.removeCallbacks(timerRunnable);
        try { if (captureSession != null) captureSession.close(); } catch (Exception ignored) {}
        captureSession = null;
        try { if (mediaRecorder != null) { mediaRecorder.reset(); mediaRecorder.release(); } } catch (Exception ignored) {}
        mediaRecorder = null;
        try { if (outputPfd != null) outputPfd.close(); } catch (Exception ignored) {}
        outputPfd = null;
        deletePendingVideo();
        if (recorderSurface != null) { recorderSurface.release(); recorderSurface = null; }
        recordButton.setText("●  START RECORDING");
        statusText.setText("CAMERA READY");
        statusText.setTextColor(0xFFB7C1CC);
        resolutionButton.setAlpha(1f);
        codecButton.setAlpha(1f);
        if (cameraDevice != null) createPreviewSession();
    }

    private void deletePendingVideo() {
        if (pendingVideoUri != null) {
            try { getContentResolver().delete(pendingVideoUri, null, null); } catch (Exception ignored) {}
            pendingVideoUri = null;
        }
    }

    private void reopenCamera() {
        closeCamera();
        openCamera();
    }

    private void closeCamera() {
        try { if (captureSession != null) captureSession.close(); } catch (Exception ignored) {}
        captureSession = null;
        try { if (cameraDevice != null) cameraDevice.close(); } catch (Exception ignored) {}
        cameraDevice = null;
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override protected void onResume() {
        super.onResume();
        if (cameraThread == null && hasPermissions()) startCameraThread();
        else if (textureView != null && textureView.isAvailable() && cameraDevice == null && hasPermissions()) openCamera();
    }

    @Override protected void onPause() {
        if (isRecording) stopRecording();
        closeCamera();
        super.onPause();
    }

    @Override protected void onDestroy() {
        closeCamera();
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(); } catch (InterruptedException ignored) {}
            cameraThread = null;
            cameraHandler = null;
        }
        super.onDestroy();
    }
}
